EJERCICIO MULTIPROCESSING

Este programa calcula la suma de números del 1 a N usando varios procesos.

Archivos:
- suma.py: contiene la función que realiza la suma.
- main.py: crea los procesos, mide el tiempo y muestra el resultado final.

Ejecución:
python main.py
